// React entry scaffold
